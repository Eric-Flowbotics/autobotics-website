# NOTICE

**Deep Boards Starter Kit** — released under the MIT License (see `LICENSE`).

## Lineage

This kit stands on earlier work, and credits it:

- The **workflow structure** (list the boards → design each with exact final
  text → render → check → look at every image) is adapted from the benai-skills
  `youtube-excalidraw` skill — MIT licensed, © 2025 BenAI.
- The **deep-board rendering system** — soft-shadowed "sticker" cards,
  code-drawn line icons, thick hand-drawn marker arrows, and frame-filling
  layout — is original to **Autobotics** (calibrated 2026-07-06). This kit is the
  genericized, MIT-licensed public port of that system. The demo palette, demo
  content, and wordmark shipped here are neutral placeholders, not any brand's
  identity.

## Bundled fonts (SIL Open Font License, Version 1.1)

The fonts in `deep-boards/scripts/fonts/` are redistributed under the SIL Open
Font License, Version 1.1, which permits bundling them with software. Full
license text ships alongside each family:

- **Plus Jakarta Sans** (ExtraBold, Bold) — © 2020 The Plus Jakarta Sans Project
  Authors (https://github.com/tokotype/PlusJakartaSans). License:
  `deep-boards/scripts/fonts/OFL-PlusJakartaSans.txt`.
- **JetBrains Mono** (Bold) — © 2020 The JetBrains Mono Project Authors
  (https://github.com/JetBrains/JetBrainsMono). License:
  `deep-boards/scripts/fonts/OFL-JetBrainsMono.txt`.

You can swap these for any `.ttf` you have the rights to use by editing the
`FONTS` paths in `deep-boards/scripts/brand_config.py`.

## What this kit does NOT do

It never calls an image model or any network service to render a board. Every
pixel is drawn locally by Pillow from your text. No API keys are required or used.

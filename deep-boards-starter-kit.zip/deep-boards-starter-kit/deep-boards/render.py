#!/usr/bin/env python3
"""
render.py — make a finished board from ONE command, with your words as arguments.

This is the reliable way to render: no editing any file, no design decisions. It
uses the kit's locked example layouts and only drops in your text — it never
invents a new layout. Set your colors first with brandkit.py, then:

  python render.py stat --number "214" --title "jobs booked last quarter" \
      --label "booked, not chased"

  python render.py checklist --title "New hire — day one" \
      --item "Laptop ready::set up before they arrive" \
      --item "Meet your buddy::a face on day one" \
      --item "Ship one small thing::done by end of day"

  python render.py flow --title "How a request moves" \
      --step "Request comes in::email or form" \
      --step "Auto-sorted::no manual triage" \
      --step "Answered::tracked to done"

  python render.py before-after --title "The intake inbox" \
      --before "Notes in five places" --before "Leads slip through" \
      --after "One place for everything" --after "Every lead gets a reply"

Row/step text can be "phrase::sub-line" (the part after :: is the small grey line)
or just "phrase". Each board saves a PNG in examples/output/ and prints the path.
Colors + wordmark always come from scripts/brand_config.py (set them with brandkit.py).
"""

import os
import argparse
import importlib.util

HERE = os.path.dirname(os.path.abspath(__file__))
EXAMPLES = os.path.join(HERE, "examples")
OUT = os.path.join(EXAMPLES, "output")


def _load(fname):
    """Import an example module by file path (runs its imports, defines build())."""
    path = os.path.join(EXAMPLES, fname)
    spec = importlib.util.spec_from_file_location(fname[:-3], path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def _pair(s):
    """'phrase::sub' -> ('phrase','sub');  'phrase' -> ('phrase','')."""
    if "::" in s:
        a, b = s.split("::", 1)
        return (a.strip(), b.strip())
    return (s.strip(), "")


def main():
    ap = argparse.ArgumentParser(
        description="Render a deep board with your words (uses the kit's locked designs).")
    sub = ap.add_subparsers(dest="type", required=True)

    p = sub.add_parser("stat", help="one big number + meaning")
    p.add_argument("--number", required=True)
    p.add_argument("--title", required=True)
    p.add_argument("--label", default="")
    p.add_argument("--sub", default="")
    p.add_argument("--brand", default="")
    p.add_argument("--context", nargs="*", default=None, help="up to 3 supporting facts")

    p = sub.add_parser("checklist", help="a few things, each with a check")
    p.add_argument("--title", required=True)
    p.add_argument("--sub", default="")
    p.add_argument("--item", action="append", required=True, help='"phrase::sub" (repeatable, up to 4)')

    p = sub.add_parser("flow", help="a short left-to-right chain")
    p.add_argument("--title", required=True)
    p.add_argument("--sub", default="")
    p.add_argument("--step", action="append", required=True, help='"label::sub" (repeatable, up to 5)')

    p = sub.add_parser("before-after", help="two columns, before vs after")
    p.add_argument("--title", required=True)
    p.add_argument("--sub", default="")
    p.add_argument("--before", action="append", required=True, help="a 'before' line (repeatable)")
    p.add_argument("--after", action="append", required=True, help="an 'after' line (repeatable)")

    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)

    if a.type == "stat":
        m = _load("01_stat_board.py")
        m.TITLE = a.title
        m.NUMBER = a.number
        m.LABEL = a.label
        m.SUB = a.sub                                   # "" by default = no sub-line
        m.BRAND = a.brand or m.mb.cfg.WORDMARK["text"].upper()   # default to the business name
        m.CONTEXT = a.context[:3] if a.context else []  # no invented supporting facts
        out = os.path.join(OUT, "stat_board.png")

    elif a.type == "checklist":
        m = _load("02_checklist_board.py")
        m.TITLE = a.title
        m.SUB = a.sub    # "" by default = just the title, no leftover demo sub-line
        m.ROWS = [_pair(x) for x in a.item][:4]
        out = os.path.join(OUT, "checklist_board.png")

    elif a.type == "flow":
        m = _load("03_process_flow.py")
        m.TITLE = a.title
        m.SUB = a.sub    # "" by default = just the title, no leftover demo sub-line
        m.STEPS = [_pair(x) for x in a.step][:5]
        out = os.path.join(OUT, "process_flow.png")

    else:  # before-after
        m = _load("04_before_after.py")
        m.TITLE = a.title
        m.SUB = a.sub    # "" by default = just the title, no leftover demo sub-line
        m.BEFORE = a.before[:4]
        m.AFTER = a.after[:4]
        out = os.path.join(OUT, "before_after.png")

    m.build().save(out)
    print("OK  ->", out)


if __name__ == "__main__":
    main()

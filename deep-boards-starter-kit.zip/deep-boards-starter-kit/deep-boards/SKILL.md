---
name: deep-boards
description: >-
  Render clean, on-brand whiteboard-style graphics ("deep boards") as
  code-drawn PNGs with Python and Pillow — zero API keys, zero image models,
  exact text and numbers every time. Use when you need a stat card, a
  process/flow diagram, a before/after comparison, a checklist, a tool map, or
  a callout card for a video, slide, social post, document, or website. Every
  color, font, and the wordmark re-brand from one file (brand_config.py).
  Triggers: deep board, make a board, whiteboard graphic, process diagram,
  flow diagram, stat card, before/after graphic, checklist graphic, explainer
  visual, render a diagram, on-screen graphic.
---

# Deep Boards

Build **deep boards** — clean, code-drawn diagrams that make one idea legible in
seconds: a stat, a flow, a before/after, a checklist. They render as
**1920×1080 PNGs** from Python + [Pillow](https://python-pillow.org/). No API
keys, no image models, no network — the code draws every pixel, so your text and
numbers are always exact and always on-brand.

Re-brand the whole system to any business by editing **one file**,
`scripts/brand_config.py`.

> **New here?** Read `QUICKSTART.md` (in the kit root) first — it renders your
> first board in about ten minutes. This file is the deeper reference for
> designing good boards and making your own.

## What makes a board "deep" (not flat)

A flat diagram is plain boxes and thin arrows floating on white. A **deep** board
has depth and craft, and it reads instantly:

- **Sticker cards** with soft offset shadows — content sits *on* the board, not *in* a table.
- **Real line icons**, code-drawn — a face on each idea.
- **Thick, hand-drawn marker arrows** — motion you can feel.
- **Frame-filling scale** — big cards, big type; nothing tiny floating in space.
- **One accent with a steady job** and quiet everything-else.

The engine (`scripts/make_boards.py`) gives you all of these as primitives. You
mostly write content and let the primitives carry the look.

## The rules (what keeps boards good)

1. **One idea per board.** A viewer has seconds. If it needs a paragraph, it's two boards.
2. **Plain language.** Short phrases, not sentences. Say the thing.
3. **Straight, never tilted.** Shadows, icons, and scale carry the hand-made feel — rotation just reads as sloppy.
4. **Give one accent one job.** Pick `accent_2` to mean a single thing — the hero number, or the "problem" side — and keep it consistent across every board. (In the examples, `accent_2` always marks the hero number and the "before" column.) Don't let it wander.
5. **Real numbers or none.** If a figure isn't real, don't put a number on the board — use a label instead. Never invent a statistic to look impressive.
6. **Zero-key, always.** Pillow renders everything. This kit never calls an image model. That's the honesty of it: what you see is drawn from your text, not hallucinated.

## The pattern library

Six patterns cover almost everything. Four ship as ready-to-run examples in
`examples/`; the last two are simple variations you compose from the same
primitives.

| Pattern | What it's for | Starts from |
|---|---|---|
| **Stat board** | one big number + what it means | `examples/01_stat_board.py` |
| **Checklist** | 3-4 things, each with a check | `examples/02_checklist_board.py` |
| **Process flow** | a short left→right chain, hero on the end | `examples/03_process_flow.py` |
| **Before / after** | two columns, one arrow between | `examples/04_before_after.py` |
| **Tool map** | rows of "name → what it does" pills | compose: sticker rows + a pill + a quiet arrow |
| **Callout card** | one big card that holds a prompt, quote, or step | compose: a dark `mono` card, or one large sticker |

## The process (how to design a good board)

1. **List the boards.** Name each one and the single idea it carries. More short boards beat one crowded board.
2. **Write the exact final text first.** The headline, each label, each sub-line — word for word, before you render. Boards live or die on the words.
3. **Assign the colors.** `accent_1` = "good / done / in-motion." `accent_2` = its one job. Everything quiet is `muted`. Ink for the words that matter.
4. **Render.** Run the script. It's a PNG in a second or two.
5. **Check the text extents.** The engine's `guard()` warns when content runs past the safe edge. Fix overflow before you ship — tighten the words or drop a size.
6. **Look at the PNG at real size.** Actually open it. "It ran without an error" is not "it looks right."

## Re-brand in one file

Open `scripts/brand_config.py` and change:

- **`PALETTE`** — your colors: `bg`, `ink`, `surface` (card color — leave white, or go dark for a dark theme), `accent_1`, `accent_2`, `muted`, `border`. Use colors your brand already owns; the two accents do the most work.
- **`FONTS`** — point `headline`, `body`, `mono` at any `.ttf`. The kit ships three open-licensed fonts in `scripts/fonts/`.
- **`WORDMARK`** — your business name, bottom-left of every board. Two-tone like a logo, or one flat color.
- **`CANVAS`** — `(1920, 1080)` for video/slides, `(1080, 1080)` for square social, `(1080, 1350)` for portrait.
- **`MARGIN`** and **`RESERVED_ZONE`** — breathing room, and an optional keep-clear box (e.g. where a webcam bubble sits in a talking-head video). Off by default.

Change nothing else. Every example and every board you build reads from this file.

## Use-case recipes (which pattern per surface)

- **Marketing & social** → the **stat board**. One number, one line, your wordmark. (Square canvas for feed posts.)
- **Internal training / SOPs** → the **checklist**. "What good looks like," 3-4 rows.
- **Docs & website** → the **process flow** or a **tool map**. Show how it works, or what runs where.
- **Client-facing docs & proposals** → the **before/after**. The universal persuader: messy left, calm right.
- **Video on-screen graphics** → any pattern, plus turn on `RESERVED_ZONE` so content never collides with your camera bubble.

## Make your own board

Copy the closest example, rename it, and change the content at the top of the
file (the `TITLE`, the rows, the number). That's it — the imports and the render
line stay the same. When you want something new, open `scripts/make_boards.py`
and read the primitives: `sticker()`, `flow_node()`, `hand_arrow()`,
`title_block()`, `wordmark()`, the `ic_*` icons, `wrap()`, `guard()`, `tint()`.
Most carry a one-line docstring, and the `ic_*` icons share one labeled section
(they all take `(d, cx, cy, s, color)`). The code *is* the spec — reference it,
don't guess.

## Troubleshooting

- **`FileNotFoundError` on a font** → a path in `FONTS` is wrong, or a `.ttf` left the `fonts/` folder. Fix the path in `brand_config.py`.
- **A `WIDTH-GUARD:` line in the output** → some text runs past the safe edge. Shorten it, or lower that font size. (It's a warning, not a crash — but fix it before shipping.)
- **Text looks cramped** → you're probably fitting too much. Split into two boards.
- **Colors look off** → check your hex values in `PALETTE`; make sure `bg` and `ink` have strong contrast.

## What ships in this kit

```
deep-boards/
├── SKILL.md            ← this file
├── scripts/
│   ├── make_boards.py  ← the engine (primitives). You rarely edit this.
│   ├── brand_config.py ← THE file you edit to re-brand everything
│   └── fonts/          ← three open-licensed fonts + their licenses
└── examples/           ← four ready-to-run board recipes
```

Zero keys. Zero image models. Your words, drawn exactly. See `NOTICE.md` and
`LICENSE` in the kit root for lineage and terms (MIT).

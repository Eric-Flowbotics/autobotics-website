#!/usr/bin/env python3
"""
Example 1 — STAT BOARD   (one big number, on a hero card)

Best for: marketing and social. The number is the star — but it sits on a
soft-shadowed hero card with an icon badge and a few supporting facts, so it
has depth and fills the frame instead of floating on an empty background.

Run it:    python 01_stat_board.py
Output:    ./output/01_stat_board.png
Re-brand:  edit ../scripts/brand_config.py
"""
import os, sys
from PIL import ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
import make_boards as mb

TITLE   = "Cups poured this year"
SUB     = "A year of early mornings and regulars."
BRAND   = "NORTHWIND COFFEE CO."
NUMBER  = "1.2M"
LABEL   = "cups poured"                    # small unit label under the number
CONTEXT = [                                # supporting facts (no invented stats)
    "14 neighborhood locations",
    "Open since 2019",
    "Every cup hand-poured",
]


def _check_dot(dd, cx, cy, r, accent):
    """A small, crisp filled check circle — reads clean at this size where a
    thin outline icon would collapse."""
    dd.ellipse([cx - r, cy - r, cx + r, cy + r], fill=accent)
    w = max(3, round(r * 0.26))
    dd.line([cx - r * 0.42, cy + r * 0.02, cx - r * 0.08, cy + r * 0.38], fill=mb.WHITE, width=w, joint="curve")
    dd.line([cx - r * 0.08, cy + r * 0.38, cx + r * 0.46, cy - r * 0.32], fill=mb.WHITE, width=w, joint="curve")


def build():
    img, _ = mb.canvas()
    img = img.convert("RGBA")
    d = ImageDraw.Draw(img)

    mb.title_block(d, TITLE, SUB)

    # ---- the hero card (soft shadow) ----
    y0, ch = 340, 590
    if CONTEXT:
        x0, cw = mb.M, mb.W - 2 * mb.M        # full width: number on the left + context column
    else:
        cw = 1040                             # just the number: a tidy tile, centered on the board
        x0 = (mb.W - cw) // 2

    def card(dd, ox, oy):
        pad = 72

        # icon badge — a rounded square in the primary accent's soft fill
        bs = 112
        bx, by = ox + pad, oy + 58
        dd.rounded_rectangle([bx, by, bx + bs, by + bs], radius=26, fill=mb.ACCENT1_FILL)
        mb.ic_star(dd, bx + bs / 2, by + bs / 2, 66, mb.ACCENT1)
        # brand line, vertically centered next to the badge
        dd.text((bx + bs + 34, by + bs / 2 - 22), BRAND, font=mb.font(mb.HEAD, 38), fill=mb.INK)

        # THE NUMBER — the star of the board
        nf = mb.font(mb.HEAD, 248)
        nx, ny = ox + pad, oy + 208
        dd.text((nx, ny), NUMBER, font=nf, fill=mb.INK)
        # measure its real box so the underline sits cleanly BELOW it
        _l, _t, _r, nb = dd.textbbox((nx, ny), NUMBER, font=nf)
        nw = _r - _l
        uy = nb + 22
        dd.rounded_rectangle([nx, uy, nx + nw * 0.58, uy + 16], radius=8, fill=mb.ACCENT2)
        # unit label under the underline
        dd.text((nx, uy + 30), LABEL, font=mb.font(mb.BODY, 40), fill=mb.MUTED)

        # ---- supporting context on the right, past a quiet divider (only if given) ----
        if CONTEXT:
            dvx = ox + int(cw * 0.60)
            dd.line([dvx, oy + 92, dvx, oy + ch - 92], fill=mb.BORDER, width=3)
            text_x = dvx + 120
            avail = (ox + cw - pad) - text_x
            # auto-fit: shrink the row text just enough that the longest line fits
            rsize = 36
            while rsize > 24 and max(dd.textlength(l, font=mb.font(mb.HEAD, rsize)) for l in CONTEXT) > avail:
                rsize -= 1
            rf = mb.font(mb.HEAD, rsize)
            ry = oy + ch / 2 - (len(CONTEXT) - 1) * 59
            for line in CONTEXT:
                _check_dot(dd, dvx + 66, ry, 26, mb.ACCENT1)
                dd.text((text_x, ry - 26), line, font=rf, fill=mb.INK)
                mb.guard(f"context '{line[:14]}'", text_x + dd.textlength(line, font=rf), limit=ox + cw - pad)
                ry += 118

    tile = mb.sticker(cw, ch, mb.SURFACE, mb.BORDER, 0, card, sw=4)
    mb.paste(img, tile, x0, y0)

    mb.wordmark(d, mb.M, mb.H - 95)
    return img.convert("RGB")


if __name__ == "__main__":
    mb.save(build(), os.path.join(HERE, "output", "01_stat_board.png"))

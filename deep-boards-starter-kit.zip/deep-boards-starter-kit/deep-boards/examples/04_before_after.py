#!/usr/bin/env python3
"""
Example 4 — BEFORE / AFTER   (two columns, one arrow between)

Best for: the universal persuader — show the messy "before" and the calm
"after" side by side. Left column uses your SECONDARY accent (problems),
right column uses your PRIMARY accent (the fix).

Run it:    python 04_before_after.py
Output:    ./output/04_before_after.png
Re-brand:  edit ../scripts/brand_config.py
"""
import os, sys
from PIL import ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
import make_boards as mb

TITLE = "Before / after: the intake inbox"
SUB   = "Same team, same week — one change to where things live."

BEFORE = ["Notes in five places", "Leads slip through", "No clear owner"]
AFTER  = ["One place for everything", "Every lead gets a reply", "One clear owner each"]


def column(title, rows, accent, icon, w, h):
    """One labelled column: a colored header band + a few icon rows."""
    band = 96
    def draw(d, ox, oy):
        # header band: rounded top corners, squared bottom, in the accent
        d.rounded_rectangle([ox, oy, ox + w, oy + band], radius=30, fill=accent)
        d.rectangle([ox, oy + band - 30, ox + w, oy + band], fill=accent)
        d.text((ox + 40, oy + band / 2 - 30), title, font=mb.font(mb.HEAD, 46), fill=mb.WHITE)
        # rows: an icon in the accent + the phrase in ink
        rf = mb.font(mb.HEAD, 38)
        step = (h - band) / len(rows)
        for i, txt in enumerate(rows):
            ry = oy + band + step * i + step / 2
            icon(d, ox + 66, ry, 62, accent)
            d.text((ox + 120, ry - 26), txt, font=rf, fill=mb.INK)
            mb.guard(f"{title} row {i+1}", ox + 120 + d.textlength(txt, font=rf), limit=ox + w - 30)
    return mb.sticker(w, h, mb.SURFACE, mb.BORDER, 0, draw, sw=4)


def build():
    img, _ = mb.canvas()
    img = img.convert("RGBA")
    d = ImageDraw.Draw(img)

    mb.title_block(d, TITLE, SUB)

    col_w, col_h, y = 740, 590, 300
    lx, rx = mb.M, 1070
    mb.paste(img, column("BEFORE", BEFORE, mb.ACCENT2, mb.ic_x, col_w, col_h), lx, y)
    mb.paste(img, column("AFTER",  AFTER,  mb.ACCENT1, mb.ic_check, col_w, col_h), rx, y)

    # the turn: one arrow from the messy side to the calm side
    cy = y + col_h / 2
    mb.hand_arrow(d, lx + col_w + 18, cy, rx - 18, cy, mb.INK, wdt=10, sag=-30)

    mb.wordmark(d, mb.M, mb.H - 95)
    return img.convert("RGB")


if __name__ == "__main__":
    mb.save(build(), os.path.join(HERE, "output", "04_before_after.png"))

#!/usr/bin/env python3
"""
Example 3 — PROCESS FLOW   (a short left-to-right chain)

Best for: docs and website — "here's how it works" in 3-5 steps.
The last node is the "hero": a solid accent card that lands the payoff.

Run it:    python 03_process_flow.py
Output:    ./output/03_process_flow.png
Re-brand:  edit ../scripts/brand_config.py   (or use ../scripts/brandkit.py)
"""
import os, sys
from PIL import ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
import make_boards as mb

TITLE = "How a support request moves"
SUB   = "Set it up once. It runs the same way every time."
# each step is (label, sub-line). Put \n in a label for a two-line label.
STEPS = [
    ("Request\ncomes in",       "email or form"),
    ("Auto-sorted\nby topic",   "no manual triage"),
    ("Routed to\nthe right rep", "with full context"),
    ("Answered",                "tracked to done"),
]


def build():
    img, _ = mb.canvas()
    img = img.convert("RGBA")
    d = ImageDraw.Draw(img)

    mb.title_block(d, TITLE, SUB)

    n = max(1, len(STEPS))
    h_, y, gap = 320, 315, 73
    w_ = 385 if n <= 4 else int((mb.W - 200 - (n - 1) * gap) / n)
    total = n * w_ + (n - 1) * gap
    x0 = int((mb.W - total) / 2)
    xs = [x0 + i * (w_ + gap) for i in range(n)]
    mids = [mb.ic_gear, mb.ic_person, mb.ic_bolt, mb.ic_clock, mb.ic_inbox]

    for i, (label, sub) in enumerate(STEPS):
        if i == 0:
            # first node — where it starts (SECONDARY accent = "raw / incoming")
            fill, stroke, ink, subink, icon = mb.ACCENT2_FILL, mb.ACCENT2, mb.INK, mb.MUTED, mb.ic_inbox
        elif i == n - 1:
            # hero node — the payoff (solid PRIMARY accent, white text)
            fill, stroke, ink, subink, icon = mb.ACCENT1, mb.ACCENT1, mb.WHITE, mb.tint(mb.ACCENT1, 0.72), mb.ic_check
        else:
            # the work in the middle (PRIMARY accent)
            fill, stroke, ink, subink, icon = mb.ACCENT1_FILL, mb.ACCENT1, mb.INK, mb.MUTED, mids[(i - 1) % len(mids)]
        mb.paste(img, mb.flow_node(w_, h_, fill, stroke, ink, subink, icon, label, sub, label_size=40), xs[i], y)

    cy = y + h_ / 2
    for i in range(n - 1):
        mb.hand_arrow(d, xs[i + 1] - 70, cy, xs[i + 1] + 4, cy, mb.ACCENT1, sag=-20)

    mb.wordmark(d, mb.M, mb.H - 95)
    return img.convert("RGB")


if __name__ == "__main__":
    mb.save(build(), os.path.join(HERE, "output", "03_process_flow.png"))

#!/usr/bin/env python3
"""
Example 3 — PROCESS FLOW   (a short left-to-right chain)

Best for: docs and website — "here's how it works" in 3-5 steps.
The last node is the "hero": a solid accent card that lands the payoff.

Run it:    python 03_process_flow.py
Output:    ./output/03_process_flow.png
Re-brand:  edit ../scripts/brand_config.py
"""
import os, sys
from PIL import ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
import make_boards as mb

TITLE = "How a support request moves"
SUB   = "Set it up once. It runs the same way every time."


def build():
    img, _ = mb.canvas()
    img = img.convert("RGBA")
    d = ImageDraw.Draw(img)

    mb.title_block(d, TITLE, SUB)

    w_, h_, y, gap = 385, 320, 315, 73
    xs = [100 + i * (w_ + gap) for i in range(4)]

    # node 1 — where it starts (uses the SECONDARY accent = "raw / incoming")
    mb.paste(img, mb.flow_node(w_, h_, mb.ACCENT2_FILL, mb.ACCENT2, mb.INK, mb.MUTED,
             mb.ic_inbox, "Request\ncomes in", "email or form", label_size=40), xs[0], y)
    # nodes 2-3 — the work (PRIMARY accent = "good / in motion")
    mb.paste(img, mb.flow_node(w_, h_, mb.ACCENT1_FILL, mb.ACCENT1, mb.INK, mb.MUTED,
             mb.ic_gear, "Auto-sorted\nby topic", "no manual triage", label_size=40), xs[1], y)
    mb.paste(img, mb.flow_node(w_, h_, mb.ACCENT1_FILL, mb.ACCENT1, mb.INK, mb.MUTED,
             mb.ic_person, "Routed to\nthe right rep", "with full context", label_size=40), xs[2], y)
    # node 4 — the hero: solid accent, white text, the payoff
    mb.paste(img, mb.flow_node(w_, h_, mb.ACCENT1, mb.ACCENT1, mb.WHITE, mb.tint(mb.ACCENT1, 0.72),
             mb.ic_check, "Answered", "tracked to done", label_size=40, hero=True), xs[3], y)

    # hand-drawn arrows between the nodes
    cy = y + h_ / 2
    for i in range(3):
        mb.hand_arrow(d, xs[i + 1] - 70, cy, xs[i + 1] + 4, cy, mb.ACCENT1, sag=-20)

    mb.wordmark(d, mb.M, mb.H - 95)
    return img.convert("RGB")


if __name__ == "__main__":
    mb.save(build(), os.path.join(HERE, "output", "03_process_flow.png"))

#!/usr/bin/env python3
"""
Example 2 — CHECKLIST BOARD   (a few things, each with a check)

Best for: internal training, SOPs, onboarding — "here's what good looks like."
Keep it to 3-4 rows. Each row = a short phrase + a one-line explanation.

Run it:    python 02_checklist_board.py
Output:    ./output/02_checklist_board.png
Re-brand:  edit ../scripts/brand_config.py
"""
import os, sys
from PIL import ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
import make_boards as mb

TITLE = "New hire — day one"
SUB   = "The first day sets the tone. Keep it simple."
ROWS  = [
    ("Laptop and logins ready",    "set up before they walk in"),
    ("Meet your onboarding buddy", "a name and a face on day one"),
    ("Ship one small thing",       "a real task, done by end of day"),
]


def build():
    img, _ = mb.canvas()
    img = img.convert("RGBA")
    d = ImageDraw.Draw(img)

    mb.title_block(d, TITLE, SUB)

    n = max(1, len(ROWS))
    w_, h_ = 1200, (158 if n <= 3 else 138)
    top, bottom = 300, 905
    step = (bottom - top - h_) / (n - 1) if n > 1 else 0
    ys = [int(top + i * step) for i in range(n)]
    for (phrase, sub), y in zip(ROWS, ys):
        def draw(dd, ox, oy, phrase=phrase, sub=sub):
            # the check circle, in your PRIMARY accent
            cx, cy = ox + 86, oy + h_ / 2
            dd.ellipse([cx - 46, cy - 46, cx + 46, cy + 46], fill=mb.ACCENT1)
            dd.line([cx - 20, cy + 2, cx - 6, cy + 18], fill=mb.WHITE, width=9, joint="curve")
            dd.line([cx - 6, cy + 18, cx + 22, cy - 16], fill=mb.WHITE, width=9, joint="curve")
            # the phrase + the quiet explanation under it
            dd.text((ox + 170, oy + 26), phrase, font=mb.font(mb.HEAD, 50), fill=mb.INK)
            dd.text((ox + 170, oy + 96), sub, font=mb.font(mb.BODY, 28), fill=mb.MUTED)
        tile = mb.sticker(w_, h_, mb.SURFACE, mb.ACCENT1, 0, draw, sw=4)
        mb.paste(img, tile, mb.M, y)

    mb.wordmark(d, mb.M, mb.H - 95)
    return img.convert("RGB")


if __name__ == "__main__":
    mb.save(build(), os.path.join(HERE, "output", "02_checklist_board.png"))

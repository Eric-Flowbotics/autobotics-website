#!/usr/bin/env python3
"""
make_boards.py  —  the deep-board rendering engine (zero-key, Pillow only).

You normally DON'T edit this file. It holds the drawing primitives every board
is built from: cards with soft offset shadows, hand-drawn marker arrows,
code-drawn line icons, title blocks, and the wordmark. Everything reads its
colors, fonts, size, and margins from brand_config.py.

To re-brand:  edit brand_config.py.
To make a new board:  copy a file from examples/ and change the content.

No API keys, no image models, no network — Pillow draws every pixel.

The look (soft-shadow "sticker" cards, real line icons, thick hand arrows,
frame-filling scale) is a genericized, MIT-licensed port of an original
deep-board system. See NOTICE.md for lineage and credits.
"""

import os
import math
from PIL import Image, ImageDraw, ImageFont

import brand_config as cfg

# ── resolve brand_config into short names the drawing code uses ───────────────
W, H          = cfg.CANVAS
M             = cfg.MARGIN
BG            = cfg.PALETTE["bg"]
INK           = cfg.PALETTE["ink"]
SURFACE       = cfg.PALETTE.get("surface", "#FFFFFF")   # card color (default white)
ACCENT1       = cfg.PALETTE["accent_1"]      # "good / done / highlight"
ACCENT2       = cfg.PALETTE["accent_2"]      # your one-job secondary accent
MUTED         = cfg.PALETTE["muted"]
BORDER        = cfg.PALETTE["border"]
ACCENT1_FILL  = cfg.FILLS["accent_1"]
ACCENT2_FILL  = cfg.FILLS["accent_2"]
NEUTRAL_FILL  = cfg.FILLS["neutral"]
SHADOW        = tuple(cfg.SHADOW)
WHITE         = "#FFFFFF"
HEAD          = cfg.FONTS["headline"]
BODY          = cfg.FONTS["body"]
MONO          = cfg.FONTS["mono"]
RESERVED_ZONE = cfg.RESERVED_ZONE

# ── fonts ─────────────────────────────────────────────────────────────────────
_fc = {}
def font(path, size):
    """Load a TrueType font at a size, cached. `path` comes from brand_config
    (HEAD / BODY / MONO). Fails loudly with a helpful message if a font is
    missing, so you know exactly what to fix in brand_config.py."""
    key = (path, size)
    if key not in _fc:
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"Font not found: {path}\n"
                f"  -> Check the FONTS paths in brand_config.py, or keep the "
                f"files in the kit's fonts/ folder."
            )
        _fc[key] = ImageFont.truetype(path, size)
    return _fc[key]

# ── text helpers ──────────────────────────────────────────────────────────────
def wrap(d, text, f, maxw):
    """Break text into lines that each fit within maxw pixels."""
    words, lines, cur = text.split(), [], ""
    for w_ in words:
        t = (cur + " " + w_).strip()
        if d.textlength(t, font=f) <= maxw:
            cur = t
        else:
            if cur:
                lines.append(cur)
            cur = w_
    if cur:
        lines.append(cur)
    return lines

def tracked(d, xy, text, f, ink, sp):
    """Draw text with extra letter-spacing (sp px between characters)."""
    x, y = xy
    for ch in text:
        d.text((x, y), ch, font=f, fill=ink)
        x += d.textlength(ch, font=f) + sp

def text_width(text, f):
    """Pixel width of a string in a font (handy for the width-guard)."""
    return _MEASURE.textlength(text, font=f)

def tint(hex_color, toward_white=0.75):
    """Lighten a hex color toward white (0 = same, 1 = white). Useful for a
    readable sub-line on a solid accent card, whatever your accent is."""
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    r = int(r + (255 - r) * toward_white)
    g = int(g + (255 - g) * toward_white)
    b = int(b + (255 - b) * toward_white)
    return f"#{r:02X}{g:02X}{b:02X}"

# ── canvas + save ─────────────────────────────────────────────────────────────
def canvas():
    """A fresh board (background color from brand_config) and its draw handle."""
    img = Image.new("RGB", (W, H), BG)
    return img, ImageDraw.Draw(img)

# a throwaway draw surface used only for measuring text
_MEASURE = ImageDraw.Draw(Image.new("RGB", (10, 10)))

def save(img, path):
    """Save a board to `path` (folders are created if needed)."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    img.save(path)
    print("OK  ->", path)
    return path

# ── brand furniture: accent bar, wordmark, title block ────────────────────────
def accent_bar(d, x, y, w=180, color=ACCENT1):
    d.rounded_rectangle([x, y, x + w, y + 14], radius=7, fill=color)

def wordmark(d, x, y):
    """The two-tone wordmark from brand_config, bottom-left by convention."""
    wf = font(HEAD, cfg.WORDMARK["size"])
    text = cfg.WORDMARK["text"]
    split = max(0, min(cfg.WORDMARK["split_at"], len(text)))
    first, rest = text[:split], text[split:]
    d.text((x, y), first, font=wf, fill=INK)
    d.text((x + d.textlength(first, font=wf), y), rest, font=wf, fill=ACCENT1)

def title_block(d, head, sub):
    """Accent bar + auto-shrinking headline + muted sub-line, top-left."""
    accent_bar(d, M, 74)
    maxw = W - 2 * M
    s = 64
    hf = font(HEAD, s)
    while d.textlength(head, font=hf) > maxw and s > 40:
        s -= 2
        hf = font(HEAD, s)
    d.text((M, 116), head, font=hf, fill=INK)
    d.text((M, 128 + int(s * 1.25)), sub, font=font(BODY, 33), fill=MUTED)

# ── sticker card (rounded card + offset shadow) ───────────────────────────────
_PAD = 80  # transparent padding around a tile so the shadow isn't clipped

def sticker(w, h, fill, stroke, angle, draw_fn, sw=5, r=30):
    """A rounded card with a soft offset shadow. `draw_fn(d, ox, oy)` paints the
    card's contents (ox, oy = top-left inside the card). `angle` stays 0 —
    deep boards read as clean and straight, never tilted."""
    tile = Image.new("RGBA", (w + 2 * _PAD, h + 2 * _PAD), (0, 0, 0, 0))
    d = ImageDraw.Draw(tile)
    d.rounded_rectangle([_PAD + 13, _PAD + 18, _PAD + w + 13, _PAD + h + 18],
                        radius=r, fill=SHADOW)
    d.rounded_rectangle([_PAD, _PAD, _PAD + w, _PAD + h],
                        radius=r, fill=fill, outline=stroke, width=sw)
    draw_fn(d, _PAD, _PAD)
    if angle:
        tile = tile.rotate(angle, resample=Image.BICUBIC, expand=True)
    return tile

def paste(img, tile, x, y):
    """Paste a sticker tile so its card's top-left lands at (x, y)."""
    img.alpha_composite(tile, (int(x - _PAD), int(y - _PAD)))

# ── hand-drawn marker arrow (curved, thick, solid head) ───────────────────────
def hand_arrow(d, x1, y1, x2, y2, color, wdt=9, sag=-26):
    """A curved marker-style arrow from (x1,y1) to (x2,y2). `sag` bends it."""
    mx, my = (x1 + x2) / 2, (y1 + y2) / 2 + sag
    pts = []
    for i in range(27):
        t = i / 26
        x = (1 - t) ** 2 * x1 + 2 * (1 - t) * t * mx + t ** 2 * x2
        y = (1 - t) ** 2 * y1 + 2 * (1 - t) * t * my + t ** 2 * y2
        pts.append((x, y))
    for i in range(len(pts) - 3):
        d.line([pts[i], pts[i + 1]], fill=color, width=wdt)
        d.ellipse([pts[i][0] - wdt / 2, pts[i][1] - wdt / 2,
                   pts[i][0] + wdt / 2, pts[i][1] + wdt / 2], fill=color)
    tx, ty = pts[-1][0] - pts[-4][0], pts[-1][1] - pts[-4][1]
    L = math.hypot(tx, ty) or 1
    ux, uy = tx / L, ty / L
    px, py = -uy, ux
    tip = (x2, y2)
    b1 = (x2 - ux * 34 + px * 16, y2 - uy * 34 + py * 16)
    b2 = (x2 - ux * 34 - px * 16, y2 - uy * 34 - py * 16)
    d.polygon([tip, b1, b2], fill=color)

# ── line icons  (signature: ic_name(d, cx, cy, s, color)) ─────────────────────
# Simple, code-drawn line icons sized by `s` (~the icon's height in px) and
# centered on (cx, cy). Use them in flow nodes or anywhere on a board.

def _isw(s):
    """Icon stroke width, scaled to the icon size so small icons stay crisp.
    (A fixed heavy stroke is exactly what makes a shrunk icon look squished.)"""
    return max(3, round(s * 0.09))

def ic_check(d, cx, cy, s, color):
    w = _isw(s)
    r = s * 0.42
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=w)
    d.line([cx - r * 0.42, cy + r * 0.04, cx - r * 0.08, cy + r * 0.40], fill=color, width=w + 1, joint="curve")
    d.line([cx - r * 0.08, cy + r * 0.40, cx + r * 0.48, cy - r * 0.34], fill=color, width=w + 1, joint="curve")

def ic_x(d, cx, cy, s, color):
    w = _isw(s)
    r = s * 0.42
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=w)
    k = r * 0.46
    d.line([cx - k, cy - k, cx + k, cy + k], fill=color, width=w + 1, joint="curve")
    d.line([cx - k, cy + k, cx + k, cy - k], fill=color, width=w + 1, joint="curve")

def ic_next(d, cx, cy, s, color):
    for off in (-s * 0.16, s * 0.18):
        d.line([cx + off - s * 0.14, cy - s * 0.30, cx + off + s * 0.16, cy], fill=color, width=9, joint="curve")
        d.line([cx + off + s * 0.16, cy, cx + off - s * 0.14, cy + s * 0.30], fill=color, width=9, joint="curve")

def _bubble(d, cx, cy, s, color):
    w_, h_ = s * 0.78, s * 0.56
    d.rounded_rectangle([cx - w_ / 2, cy - h_ / 2 - 4, cx + w_ / 2, cy + h_ / 2 - 10], radius=14, outline=color, width=6)
    d.polygon([(cx - w_ / 4, cy + h_ / 2 - 12), (cx - w_ / 4 + 22, cy + h_ / 2 - 12), (cx - w_ / 4 - 2, cy + h_ / 2 + 12)], fill=color)

def ic_bubble(d, cx, cy, s, color):
    _bubble(d, cx, cy, s, color)
    y = cy - 6
    d.line([cx + s * 0.20, y, cx - s * 0.16, y], fill=color, width=6)
    d.line([cx - s * 0.16, y, cx - s * 0.02, y - s * 0.11], fill=color, width=6)
    d.line([cx - s * 0.16, y, cx - s * 0.02, y + s * 0.11], fill=color, width=6)

def ic_bolt(d, cx, cy, s, color):
    d.line([cx + s * 0.16, cy - s * 0.34, cx - s * 0.16, cy + s * 0.04], fill=color, width=7, joint="curve")
    d.line([cx - s * 0.16, cy + s * 0.04, cx + s * 0.06, cy + s * 0.04], fill=color, width=7, joint="curve")
    d.line([cx + s * 0.06, cy + s * 0.04, cx - s * 0.14, cy + s * 0.34], fill=color, width=7, joint="curve")

def ic_inbox(d, cx, cy, s, color):
    w_, h_ = s * 0.72, s * 0.56
    d.rounded_rectangle([cx - w_ / 2, cy - h_ / 2, cx + w_ / 2, cy + h_ / 2], radius=10, outline=color, width=6)
    d.line([cx - w_ / 2, cy + h_ * 0.10, cx - w_ * 0.20, cy + h_ * 0.10], fill=color, width=6)
    d.line([cx - w_ * 0.20, cy + h_ * 0.10, cx - w_ * 0.08, cy + h_ * 0.30], fill=color, width=6)
    d.line([cx - w_ * 0.08, cy + h_ * 0.30, cx + w_ * 0.08, cy + h_ * 0.30], fill=color, width=6)
    d.line([cx + w_ * 0.08, cy + h_ * 0.30, cx + w_ * 0.20, cy + h_ * 0.10], fill=color, width=6)
    d.line([cx + w_ * 0.20, cy + h_ * 0.10, cx + w_ / 2, cy + h_ * 0.10], fill=color, width=6)

def ic_gear(d, cx, cy, s, color):
    r = s * 0.30
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=6)
    d.ellipse([cx - r * 0.38, cy - r * 0.38, cx + r * 0.38, cy + r * 0.38], outline=color, width=5)
    for k in range(8):
        a = k * math.pi / 4
        x0, y0 = cx + math.cos(a) * r, cy + math.sin(a) * r
        x1, y1 = cx + math.cos(a) * (r + s * 0.14), cy + math.sin(a) * (r + s * 0.14)
        d.line([x0, y0, x1, y1], fill=color, width=7)

def ic_person(d, cx, cy, s, color):
    hr = s * 0.17
    d.ellipse([cx - hr, cy - s * 0.34, cx + hr, cy - s * 0.34 + 2 * hr], outline=color, width=6)
    d.arc([cx - s * 0.30, cy - s * 0.04, cx + s * 0.30, cy + s * 0.56], start=180, end=360, fill=color, width=6)

def ic_clock(d, cx, cy, s, color):
    r = s * 0.36
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=6)
    d.line([cx, cy, cx, cy - r * 0.55], fill=color, width=6)
    d.line([cx, cy, cx + r * 0.42, cy + r * 0.12], fill=color, width=6)

def ic_doc(d, cx, cy, s, color):
    w_, h_ = s * 0.52, s * 0.68
    fold = s * 0.18
    x0, y0, x1, y1 = cx - w_ / 2, cy - h_ / 2, cx + w_ / 2, cy + h_ / 2
    d.line([x0, y0, x1 - fold, y0], fill=color, width=6)
    d.line([x0, y0, x0, y1], fill=color, width=6)
    d.line([x0, y1, x1, y1], fill=color, width=6)
    d.line([x1, y1, x1, y0 + fold], fill=color, width=6)
    d.line([x1 - fold, y0, x1, y0 + fold], fill=color, width=6)
    for i in range(3):
        yy = y0 + h_ * 0.42 + i * h_ * 0.16
        d.line([x0 + w_ * 0.18, yy, x1 - w_ * 0.18, yy], fill=color, width=5)

def ic_star(d, cx, cy, s, color):
    r, ri = s * 0.40, s * 0.17
    pts = []
    for k in range(10):
        rad = r if k % 2 == 0 else ri
        a = -math.pi / 2 + k * math.pi / 5
        pts.append((cx + math.cos(a) * rad, cy + math.sin(a) * rad))
    d.polygon(pts, outline=color, width=6)

def ic_flag(d, cx, cy, s, color):
    x0 = cx - s * 0.22
    d.line([x0, cy - s * 0.38, x0, cy + s * 0.40], fill=color, width=6)
    d.polygon([(x0, cy - s * 0.36), (x0 + s * 0.44, cy - s * 0.22), (x0, cy - s * 0.06)], outline=color, width=6)

# ── flow node (icon + label + sub, on a sticker card) ─────────────────────────
def flow_node(w, h, fill, stroke, ink, sub_ink, icon, label, sub, angle=0,
              label_size=46, hero=False):
    """One node in a process flow: a sticker card with a line icon, a bold
    label (use \\n for two lines), and a small sub-line. `hero=True` makes it a
    solid accent card with white text — good for the final 'done' step."""
    def draw(d, ox, oy):
        icon(d, ox + w / 2, oy + 92, 88, (WHITE if hero else stroke))
        lf = font(HEAD, label_size)
        lines = label.split("\n")
        lh = int(label_size * 1.16)
        y = oy + 148 + max(0, (108 - len(lines) * lh) / 2)
        for ln in lines:
            d.text((ox + (w - d.textlength(ln, font=lf)) / 2, y), ln, font=lf, fill=ink)
            y += lh
        sf = font(BODY, 27)
        d.text((ox + (w - d.textlength(sub, font=sf)) / 2, oy + h - 64), sub, font=sf, fill=sub_ink)
    return sticker(w, h, fill, stroke, angle, draw)

# ── width-guard (catch text/content that overflows before you ship) ───────────
def guard(name, x_right, limit=None, reserved=True):
    """Warn if content runs past a safe limit. Pass the right-most x you drew
    to (x_right). `limit` defaults to the right margin (W - MARGIN). If a
    RESERVED_ZONE is set in brand_config and `reserved` is True, its left edge
    is used instead. Returns True if clear, False if it overflows."""
    if limit is None:
        limit = W - M
        if reserved and RESERVED_ZONE is not None:
            limit = min(limit, RESERVED_ZONE[0] - 24)
    if x_right > limit:
        print(f"  WIDTH-GUARD: '{name}' reaches {int(x_right)}px but the clear "
              f"limit is {int(limit)}px — tighten the text or move it left.")
        return False
    return True

"""
brand_config.py  —  Make the boards your own.

This is the ONE file you edit to re-brand every board to your business.
Change the colors, fonts, and wordmark here; every example and every board
you build reads from this file automatically. Nothing else has to change.

It's all plain Python. If you can change a word between quotes, you can
re-brand this whole kit. Start with WORDMARK["text"] and the two accent
colors, render an example, and go from there.
"""

import os

# ── 1. COLORS ────────────────────────────────────────────────────────────────
# Hex colors, the same kind any design tool uses. Fill in each role below.
# Pick colors your brand already uses. The two accents do the most work.
# (Card color is `surface` — leave it white, or set it dark for a dark theme.)
PALETTE = {
    "bg":       "#F5F4F0",   # the paper / background of every board
    "ink":      "#22252A",   # main text color (a near-black reads best)
    "surface":  "#FFFFFF",   # card color (usually white; set it dark for a dark theme)
    "accent_1": "#2F5FE0",   # PRIMARY accent — your "good / done / highlight" color
    "accent_2": "#D6336C",   # SECONDARY accent — give it ONE steady job (see SKILL.md)
    "muted":    "#6B7280",   # sub-labels, quiet text, quiet arrows
    "border":   "#D9D5CC",   # thin outline for cards that have no strong fill
}

# Soft "fill" tints painted inside cards. If you'd rather not fuss with these,
# leave them — they're just light washes of the two accents plus a light gray.
FILLS = {
    "accent_1": "#E7ECFB",   # a light wash of accent_1
    "accent_2": "#FBE7EF",   # a light wash of accent_2
    "neutral":  "#EDEDEA",   # a light neutral gray
}

# The soft drop shadow under every card: (Red, Green, Blue, Alpha).
# Bigger Alpha = heavier shadow. This depth is what makes a board feel
# "placed by hand" instead of flat. You rarely need to touch it.
SHADOW = (28, 32, 36, 64)

# ── 2. FONTS ─────────────────────────────────────────────────────────────────
# The kit ships three fonts in ./fonts . You can point these at any .ttf file.
#   headline = a heavy display weight (big titles, numbers, card labels)
#   body     = a lighter bold weight (sub-lines and quiet text)
#   mono     = a monospace (great for numbers, prompts, and code-style cards)
_FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")

FONTS = {
    "headline": os.path.join(_FONT_DIR, "PlusJakartaSans-ExtraBold.ttf"),
    "body":     os.path.join(_FONT_DIR, "PlusJakartaSans-Bold.ttf"),
    "mono":     os.path.join(_FONT_DIR, "JetBrainsMono-Bold.ttf"),
}

# ── 3. WORDMARK  (your name, sits bottom-left of every board) ─────────────────
# Two-tone, like a simple logo: the first letters stay "ink", the rest turn
# accent_1. SPLIT_AT is how many letters stay ink. Set SPLIT_AT = 0 for one
# flat ink color.  Example: text "northwind", split_at 5  ->  north + wind
WORDMARK = {
    "text":     "northwind",   # ← put your business name here (lowercase reads clean)
    "split_at": 5,             # letters kept in ink before accent_1 takes over (0 = all ink)
    "size":     42,
}

# ── 4. LAYOUT ────────────────────────────────────────────────────────────────
CANVAS = (1920, 1080)   # board size in pixels. Common choices:
                        #   16:9 video / slides  ->  (1920, 1080)
                        #   square social        ->  (1080, 1080)
                        #   portrait social      ->  (1080, 1350)
MARGIN = 110            # clear breathing room around the edges, in pixels.

# ── 5. RESERVED ZONE  (optional — off by default) ────────────────────────────
# A rectangle to keep clear of content — for example, the corner where a
# webcam bubble sits in a talking-head video. None = use the whole frame.
# To turn it on, give it a box in pixels:  (x1, y1, x2, y2)
#   RESERVED_ZONE = (1330, 660, 1870, 1030)
RESERVED_ZONE = None

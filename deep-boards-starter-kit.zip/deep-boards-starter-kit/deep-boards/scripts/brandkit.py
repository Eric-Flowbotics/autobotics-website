#!/usr/bin/env python3
"""
brandkit.py  —  set the kit's brand FOR you (colors + wordmark), then you render.

Zero network, Pillow only. Three ways to brand, and an --apply that writes your
choice straight into brand_config.py (colors + wordmark), preserving the file's
comments. Without --apply it just PRINTS the suggestion so you can paste it.

  1) From a logo image  (recommended — works on any machine, no internet):
       python brandkit.py logo mylogo.png --name "Acme" --apply

  2) From a professional preset  (no brand yet? pick a clean one):
       python brandkit.py presets                        # list them
       python brandkit.py preset "Slate & Blue" --name "Acme" --apply

  3) From explicit colors  (you already know your hex codes):
       python brandkit.py colors --accent1 "#2F5FE0" --accent2 "#E8590C" --name "Acme" --apply

Reading a website's colors needs live web access, which this offline helper does
not have. Ask your AI assistant to read the site and hand you the hex codes, then
use `colors` — or just point `logo` at the company's logo image.
"""

import os
import re
import sys
import argparse
import colorsys

HERE = os.path.dirname(os.path.abspath(__file__))


# ── color helpers ─────────────────────────────────────────────────────────────
def _rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

def _hex(rgb):
    return "#{:02X}{:02X}{:02X}".format(*[max(0, min(255, int(round(c)))) for c in rgb])

def _sat(rgb):
    r, g, b = [c / 255 for c in rgb]
    return colorsys.rgb_to_hls(r, g, b)[2]

def _lum(rgb):
    r, g, b = rgb
    return 0.299 * r + 0.587 * g + 0.114 * b

def _hue(rgb):
    r, g, b = [c / 255 for c in rgb]
    return colorsys.rgb_to_hls(r, g, b)[0] * 360

def _mix(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))

def _wash(hexcolor, t):
    return _hex(_mix(_rgb(hexcolor), (255, 255, 255), t))

def _complement(rgb):
    r, g, b = [c / 255 for c in rgb]
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    h = (h + 0.5) % 1.0
    l = min(0.55, max(0.42, l))
    s = max(0.5, s)
    return tuple(round(c * 255) for c in colorsys.hls_to_rgb(h, l, s))


# ── professional presets (for the "no brand yet" path) ────────────────────────
PRESETS = {
    "Slate & Blue": dict(
        palette=dict(bg="#F4F6F9", ink="#1B2230", surface="#FFFFFF",
                     accent_1="#2F5FE0", accent_2="#E8590C", muted="#66707E", border="#DCE0E7"),
        fills=dict(accent_1="#E7ECFB", accent_2="#FBE7DA", neutral="#ECEEF1"),
        shadow=(28, 32, 36, 64)),
    "Ink & Emerald": dict(
        palette=dict(bg="#F5F6F2", ink="#14201B", surface="#FFFFFF",
                     accent_1="#0E9F6E", accent_2="#6D28D9", muted="#66706B", border="#DADDD6"),
        fills=dict(accent_1="#E3F4EC", accent_2="#EEE7FB", neutral="#ECEDE9"),
        shadow=(28, 32, 36, 64)),
    "Charcoal & Coral": dict(
        palette=dict(bg="#F7F5F4", ink="#22252A", surface="#FFFFFF",
                     accent_1="#E5533C", accent_2="#2563A8", muted="#6E7075", border="#E2DCD7"),
        fills=dict(accent_1="#FBE7E1", accent_2="#E4EDF7", neutral="#EEEBE8"),
        shadow=(28, 32, 36, 64)),
    "Midnight (dark)": dict(
        palette=dict(bg="#0F1420", ink="#F2F4F8", surface="#171E2E",
                     accent_1="#4C8DFF", accent_2="#F5A524", muted="#9AA4B2", border="#2A3346"),
        fills=dict(accent_1="#14233B", accent_2="#3A2E14", neutral="#1B2333"),
        shadow=(0, 0, 0, 95)),
}


def suggest_from_image(path):
    """Pull two main brand colors from a logo and build a coherent light palette."""
    from PIL import Image
    im = Image.open(path).convert("RGBA")
    flat = Image.new("RGBA", im.size, (255, 255, 255, 255))
    im = Image.alpha_composite(flat, im).convert("RGB")
    im.thumbnail((240, 240))
    q = im.quantize(colors=16, method=Image.MEDIANCUT).convert("RGB")
    counts = sorted(q.getcolors(maxcolors=100000), reverse=True)  # (count, (r,g,b))

    cand = []
    for count, rgb in counts:
        if min(rgb) > 236:          # skip near-white
            continue
        if max(rgb) < 22:           # skip near-black
            continue
        cand.append((count * (0.25 + _sat(rgb)), count, rgb, _sat(rgb)))
    cand.sort(reverse=True)

    if cand:
        accent1 = cand[0][2]
        a1h = _hue(accent1)
        accent2 = None
        for _, __, rgb, s in cand[1:]:
            if s < 0.16:
                continue
            dh = abs(_hue(rgb) - a1h)
            dh = min(dh, 360 - dh)
            if dh > 40:
                accent2 = rgb
                break
        if accent2 is None:
            accent2 = _complement(accent1)
    else:
        accent1, accent2 = (47, 95, 224), (232, 89, 12)

    darks = [rgb for _, rgb in counts if _lum(rgb) < 70 and _sat(rgb) < 0.6]
    ink = _hex(min(darks, key=_lum)) if darks else "#1E232B"
    a1 = _hex(accent1)
    a2 = _hex(accent2)

    palette = dict(bg=_wash(a1, 0.95), ink=ink, surface="#FFFFFF",
                   accent_1=a1, accent_2=a2, muted="#6B7280", border="#DCDDE1")
    fills = dict(accent_1=_wash(a1, 0.86), accent_2=_wash(a2, 0.86), neutral="#ECECEA")
    note = (f"Pulled your two main colors from the logo: accent_1 {a1} (primary) "
            f"and accent_2 {a2} (secondary). Neutrals were chosen for clean, "
            f"readable contrast. Tweak any value in brand_config.py.")
    return palette, fills, (28, 32, 36, 64), note


# ── write the choice into brand_config.py (keeps comments) ────────────────────
def _patch_block(src, header, values):
    m = re.search(re.escape(header) + r".*?\n\}", src, re.DOTALL)
    if not m:
        return src
    block = m.group(0)
    new = block
    for k, v in values.items():
        new = re.sub(r'("' + re.escape(k) + r'":\s*")#[0-9A-Fa-f]{6}(")',
                     lambda mm, v=v: mm.group(1) + v + mm.group(2), new)
    return src.replace(block, new)

def apply_brand(scripts_dir, palette, fills, shadow, wordmark_text=None):
    cfg = os.path.join(scripts_dir, "brand_config.py")
    with open(cfg, "r", encoding="utf-8") as fh:
        src = fh.read()
    src = _patch_block(src, "PALETTE = {", palette)
    src = _patch_block(src, "FILLS = {", fills)
    src = re.sub(r"SHADOW = \([^)]*\)", "SHADOW = ({}, {}, {}, {})".format(*shadow), src)
    if wordmark_text:
        wt = wordmark_text.strip()
        split = wt.find(" ") if " " in wt else len(wt) // 2
        src = _patch_block2_wordmark(src, wt, split)
    with open(cfg, "w", encoding="utf-8") as fh:
        fh.write(src)
    return cfg

def _patch_block2_wordmark(src, text, split):
    m = re.search(r"WORDMARK = \{.*?\n\}", src, re.DOTALL)
    if not m:
        return src
    block = m.group(0)
    new = re.sub(r'("text":\s*")[^"]*(")', lambda mm: mm.group(1) + text + mm.group(2), block)
    new = re.sub(r'("split_at":\s*)\d+', lambda mm: mm.group(1) + str(split), new)
    return src.replace(block, new)


def _print_suggestion(palette, fills, shadow, note=None, name=None):
    if note:
        print("\n" + note + "\n")
    print("Suggested brand_config.py values (paste over the matching blocks):\n")
    print("PALETTE = {")
    for k in ("bg", "ink", "surface", "accent_1", "accent_2", "muted", "border"):
        print(f'    "{k}":{" " * (9 - len(k))}"{palette[k]}",')
    print("}")
    print("FILLS = {")
    for k in ("accent_1", "accent_2", "neutral"):
        print(f'    "{k}":{" " * (9 - len(k))}"{fills[k]}",')
    print("}")
    print("SHADOW = ({}, {}, {}, {})".format(*shadow))
    if name:
        wt = name.strip()
        split = wt.find(" ") if " " in wt else len(wt) // 2
        print(f'WORDMARK["text"] = "{wt}"      # and set WORDMARK["split_at"] = {split}')


def main():
    ap = argparse.ArgumentParser(description="Brand the Deep Boards kit for you.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("presets", help="list the built-in professional palettes")

    p_pre = sub.add_parser("preset", help="use a named preset")
    p_pre.add_argument("preset")

    p_logo = sub.add_parser("logo", help="derive colors from a logo image")
    p_logo.add_argument("path")

    p_col = sub.add_parser("colors", help="use explicit hex colors")
    p_col.add_argument("--accent1", required=True)
    p_col.add_argument("--accent2", required=True)
    p_col.add_argument("--dark", action="store_true", help="build a dark theme")

    for p in (p_pre, p_logo, p_col):
        p.add_argument("--name", help="your business name (sets the wordmark)")
        p.add_argument("--apply", action="store_true", help="write it into brand_config.py")
        p.add_argument("--scripts-dir", default=HERE)

    args = ap.parse_args()

    if args.cmd == "presets":
        print("Professional presets (use:  python brandkit.py preset \"NAME\" --name \"You\" --apply):\n")
        for name, spec in PRESETS.items():
            pp = spec["palette"]
            print(f"  • {name:18s}  accent_1 {pp['accent_1']}  accent_2 {pp['accent_2']}  bg {pp['bg']}")
        return

    if args.cmd == "preset":
        spec = PRESETS.get(args.preset)
        if not spec:
            print(f"No preset named {args.preset!r}. Run:  python brandkit.py presets")
            sys.exit(1)
        palette, fills, shadow = spec["palette"], spec["fills"], spec["shadow"]
        note = f"Using the professional preset '{args.preset}'."
    elif args.cmd == "logo":
        if not os.path.exists(args.path):
            print(f"Logo not found: {args.path}")
            sys.exit(1)
        palette, fills, shadow, note = suggest_from_image(args.path)
    else:  # colors
        a1, a2 = args.accent1, args.accent2
        if args.dark:
            palette = dict(bg="#0F1420", ink="#F2F4F8", surface="#171E2E",
                           accent_1=a1, accent_2=a2, muted="#9AA4B2", border="#2A3346")
            fills = dict(accent_1=_wash(a1, 0.80), accent_2=_wash(a2, 0.80), neutral="#1B2333")
            shadow = (0, 0, 0, 95)
        else:
            palette = dict(bg=_wash(a1, 0.95), ink="#1E232B", surface="#FFFFFF",
                           accent_1=a1, accent_2=a2, muted="#6B7280", border="#DCDDE1")
            fills = dict(accent_1=_wash(a1, 0.86), accent_2=_wash(a2, 0.86), neutral="#ECECEA")
            shadow = (28, 32, 36, 64)
        note = f"Using your colors: accent_1 {a1}, accent_2 {a2}."

    if args.apply:
        cfg = apply_brand(args.scripts_dir, palette, fills, shadow, args.name)
        who = f' and wordmark "{args.name}"' if args.name else ""
        example = os.path.normpath(os.path.join(args.scripts_dir, "..", "examples", "01_stat_board.py"))
        print(f"{note}\nApplied colors{who} to {cfg}")
        print(f'Now render a board:  python "{example}"')
    else:
        _print_suggestion(palette, fills, shadow, note, args.name)
        print('\nAdd  --apply  to write these into brand_config.py automatically.')


if __name__ == "__main__":
    main()

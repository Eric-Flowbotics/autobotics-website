# Start here

You don't have to touch any code. **Upload this kit to your AI assistant and paste
the prompt below** — it will ask a few questions, brand the kit to your business,
and hand you a finished image.

Works on any assistant with a real code tool — **Claude** and **ChatGPT** are
confirmed. (Gemini's code tool can't read or write files, so it can't render
in-chat — see the "Which assistants" note at the bottom.) Prefer to do it yourself
with no AI? Skip to **`QUICKSTART.md`**.

---

## The prompt — copy everything in the box

> You are helping me turn the "Deep Boards" kit I just uploaded into a finished,
> on-brand image (a "deep board"). The kit is a folder named
> `deep-boards-starter-kit` with Python scripts that render PNGs using Pillow —
> no API keys, no image models. Do all of this with your code / Python tool, and
> ALWAYS run the kit's own scripts — never draw your own board or use an image
> generator.
>
> **Paths — read first.** Unzipping makes a folder named `deep-boards-starter-kit`
> with a `deep-boards/` folder inside it. `cd` into `deep-boards-starter-kit` (so
> every path below resolves), or put it in front of each path. Before step 2,
> confirm you can actually open `deep-boards/scripts/brandkit.py` and
> `deep-boards/examples/01_stat_board.py`. If you can't, find where `deep-boards`
> landed and use that real path — do NOT continue by improvising a board.
>
> Go one step at a time and wait for my answer at each step:
>
> **1. Setup.** Unzip the kit file I just uploaded (whatever it's named — it makes a
> folder named `deep-boards-starter-kit`), `cd` into that folder, and confirm
> `deep-boards/scripts/` and `deep-boards/examples/` are really there. If Pillow
> isn't installed, run `pip install pillow`. If you can't find the files, ask me to
> re-upload the kit.
>
> **2. My business.** Ask me my business name (it becomes the wordmark on every board).
>
> **3. My colors.** Ask how I want to set my brand colors, and offer these options:
> - *"I'll paste my website URL"* — use your own web/browsing ability to read that
>   page and find my 2 main brand colors, then tell me the hex codes you found. If
>   you can't browse, say so and ask for my logo or hex codes instead.
> - *"I'll upload my logo"* — after I upload it, run:
>   `python deep-boards/scripts/brandkit.py logo <my-logo-file> --name "<my business>" --apply`
> - *"I don't have brand colors"* — run `python deep-boards/scripts/brandkit.py presets`,
>   pick ONE clean palette for me, tell me its name and the two accent colors, then apply it:
>   `python deep-boards/scripts/brandkit.py preset "<name>" --name "<my business>" --apply`
> - *"Here are my hex codes"* — run:
>   `python deep-boards/scripts/brandkit.py colors --accent1 "#XXXXXX" --accent2 "#XXXXXX" --name "<my business>" --apply`
>
> **4. The board.** Ask what I want to show and match it to a type — a big
> number/stat, a checklist, a step-by-step (boxes in a row), or a before/after.
> Ask me for the exact words, and if it's a stat, the exact number. **Use ONLY
> real numbers I give you — never invent, round up, or estimate. No number? Use a
> short phrase.**
>
> **5. Render — ONE command, no editing.** Run the kit's `render.py` with my words
> as arguments and show me the PNG it saves in `deep-boards/examples/output/`. Do
> NOT edit any script, write your own drawing code, or design your own layout —
> `render.py` already makes the on-brand board. Use the matching template:
> - stat: `python deep-boards/render.py stat --number "214" --title "jobs booked last quarter" --label "booked, not chased"`
> - checklist: `python deep-boards/render.py checklist --title "New hire — day one" --item "Laptop ready::set up before they arrive" --item "Meet your buddy::a face on day one"`
> - flow (boxes): `python deep-boards/render.py flow --title "How a missed call becomes a booking" --step "Call comes in::you're on a job" --step "Auto-text fires::in ~30 seconds" --step "They reply::conversation starts" --step "Job booked::saved, not lost"`
> - before/after: `python deep-boards/render.py before-after --title "The intake inbox" --before "Notes everywhere" --before "Leads slip" --after "One place" --after "Every lead replied"`
> (A row/step can be `"phrase::small grey sub-line"` or just `"phrase"`.)
>
> **6. Iterate.** Ask if I want changes (wording, colors, a different board) and repeat.
>
> Rules: the board is drawn by the kit's Python code, never by an image generator —
> so my text and numbers come out exactly as written. If a command errors "file not
> found," it's the folder path — find the real path to `deep-boards` and use it.
> Never write your own drawing code, use an image generator, or design your own
> layout — only `render.py` makes boards (and `brandkit.py` sets colors). If you
> think a board should look different, tell me — don't rebuild it. Keep colors and
> wordmark consistent (they all read from `deep-boards/scripts/brand_config.py`).
> One idea per board.

---

## What happens next

The assistant asks your name, sets your colors (from your website, your logo, or a
clean default it picks for you), asks what the board should say, and shows you the
finished PNG. Ask for tweaks in plain language.

## No AI assistant? Do it yourself in two minutes

Run these from inside the unzipped `deep-boards-starter-kit` folder:

```bash
python3 -m pip install pillow

# brand it (pick one):
python3 deep-boards/scripts/brandkit.py logo mylogo.png --name "My Co" --apply
python3 deep-boards/scripts/brandkit.py preset "Slate & Blue" --name "My Co" --apply
python3 deep-boards/scripts/brandkit.py colors --accent1 "#2F5FE0" --accent2 "#E8590C" --name "My Co" --apply

# render a board:
python3 deep-boards/examples/01_stat_board.py      # → deep-boards/examples/output/
```

Full walkthrough in **`QUICKSTART.md`**; design guidance in `deep-boards/SKILL.md`.

## Which assistants can render in-chat?

An assistant whose **code tool can read and write files** can run the kit and show
you the PNG: **Claude** (Cowork, Claude Code, or as an installed skill) and
**ChatGPT** (its code tool / "code interpreter"). **Gemini's code tool doesn't
support file reading/writing** (a Google limitation, even in AI Studio), so it
can't render this kit in-chat — use Claude or ChatGPT, or the do-it-yourself path.
Plain **claude.ai web chat with no code tool can't run Python** either. See
`README.md` → "Use it on any AI" for the exact per-assistant steps.

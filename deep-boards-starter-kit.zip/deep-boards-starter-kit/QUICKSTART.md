# Quickstart — your first board in ~10 minutes

You need **Python 3** and **Pillow** (the drawing library). Nothing else. No
accounts, no API keys.

---

## Step 0 — install Pillow (once, ~1 min)

```bash
python3 -m pip install pillow
```

## Step 1 — render an example exactly as-is (~2 min)

From inside the kit folder:

```bash
cd deep-boards/examples
python3 01_stat_board.py
```

You'll see:

```
OK  ->  .../deep-boards/examples/output/01_stat_board.png
```

Open that PNG. That's a finished deep board. (The demo brand is a made-up
company called "Northwind" — you'll change that next.)

## Step 2 — make it yours (~5 min)

Two small edits.

**A. Your name on every board.** Open `deep-boards/scripts/brand_config.py` and
change one line:

```python
WORDMARK = {
    "text":     "yourbrand",   # ← put your business name here
    "split_at": 0,             # 0 = one flat color (simplest)
    "size":     42,
}
```

**B. Your number and words.** Open `deep-boards/examples/01_stat_board.py` and
change the lines near the top:

```python
BRAND   = "YOUR COMPANY"
TITLE   = "Hours back every week"
NUMBER  = "12"
LABEL   = "hours saved"
# CONTEXT = [...]  three short supporting facts, edit or leave them
```

Re-run `python3 01_stat_board.py` and open the new PNG. It's yours.

> Only put a **real** number on a stat board. If you don't have one, use a word
> instead ("Faster") — never invent a statistic to look impressive.

## Step 3 — your colors (optional, ~2 min)

In `brand_config.py`, change the two accent colors to ones your brand already
uses:

```python
PALETTE = {
    ...
    "accent_1": "#2F5FE0",   # your PRIMARY color  (the "good / done" color)
    "accent_2": "#D6336C",   # your SECONDARY color (give it one steady job)
    ...
}
```

Re-run any example. Every board picks up the new colors — nothing else to change.

---

## Faster still — if you use Claude with this skill installed

Paste this into Claude (after installing the kit as a skill — see `README.md`):

> **Use the deep-boards skill to make me a stat board. My company is
> "\<your name\>". The number is "\<your number\>" and it means "\<one short
> line\>". Set the wordmark to my company name, render it, and show me the PNG.**

Claude will edit the config, run the script, and show you the result.

## Where to go next

- `README.md` — what deep boards are, and how to install the skill on your setup.
- `deep-boards/SKILL.md` — the six board patterns and how to design good ones.
- `deep-boards/examples/` — four recipes to copy: stat, checklist, process flow, before/after.

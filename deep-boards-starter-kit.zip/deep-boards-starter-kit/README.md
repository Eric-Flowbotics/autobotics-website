# Deep Boards — Starter Kit

Make clean, on-brand whiteboard-style graphics — **deep boards** — as code-drawn
PNGs. A stat card, a process flow, a before/after, a checklist: the visuals that
make one idea land in seconds.

**Zero keys. Zero image models. Zero hallucinated numbers.** Every board is drawn
by [Pillow](https://python-pillow.org/) from the text you give it, so your words
and figures are always exact and always on-brand. Re-brand the whole system to
any business by editing **one file**.

<p align="center">
  <img src="examples/01_stat_board.png" width="48%" alt="Stat board example">
  <img src="examples/03_process_flow.png" width="48%" alt="Process flow example"><br>
  <img src="examples/04_before_after.png" width="48%" alt="Before / after example">
  <img src="examples/02_checklist_board.png" width="48%" alt="Checklist example">
</p>

*(The demo brand — "Northwind" — is made up. The colors are the kit's own neutral
demo palette. Swap in yours in one file — or let your AI do it, below.)*

---

## Fastest way — upload it, let your AI brand it

Upload this kit to an AI assistant that can run Python, and paste the prompt below.
It asks a few questions, brands the kit to **your** business — from your website,
your logo, or a clean default it picks for you — and shows you the finished image.
No code, no design work. (Same prompt lives in **`START-HERE.md`**.)

> You are helping me turn the "Deep Boards" kit I just uploaded into a finished,
> on-brand image (a "deep board"). The kit is a folder named
> `deep-boards-starter-kit` with Python scripts that render PNGs using Pillow —
> no API keys, no image models. Do all of this with your code / Python tool, and
> ALWAYS run the kit's own scripts — never draw your own board or use an image
> generator.
>
> **Paths — read first.** Unzipping makes a folder named `deep-boards-starter-kit`
> with a `deep-boards/` folder inside it. `cd` into `deep-boards-starter-kit` (so
> every path below resolves), or put it in front of each path. Before step 2,
> confirm you can actually open `deep-boards/scripts/brandkit.py` and
> `deep-boards/examples/01_stat_board.py`. If you can't, find where `deep-boards`
> landed and use that real path — do NOT continue by improvising a board.
>
> Go one step at a time and wait for my answer at each step:
>
> **1. Setup.** Unzip the kit file I just uploaded (whatever it's named — it makes a
> folder named `deep-boards-starter-kit`), `cd` into that folder, and confirm
> `deep-boards/scripts/` and `deep-boards/examples/` are really there. If Pillow
> isn't installed, run `pip install pillow`. If you can't find the files, ask me to
> re-upload the kit.
>
> **2. My business.** Ask me my business name (it becomes the wordmark on every board).
>
> **3. My colors.** Ask how I want to set my brand colors, and offer these options:
> - *"I'll paste my website URL"* — use your own web/browsing ability to read that
>   page and find my 2 main brand colors, then tell me the hex codes you found. If
>   you can't browse, say so and ask for my logo or hex codes instead.
> - *"I'll upload my logo"* — after I upload it, run:
>   `python deep-boards/scripts/brandkit.py logo <my-logo-file> --name "<my business>" --apply`
> - *"I don't have brand colors"* — run `python deep-boards/scripts/brandkit.py presets`,
>   pick ONE clean palette for me, tell me its name and the two accents, then apply it:
>   `python deep-boards/scripts/brandkit.py preset "<name>" --name "<my business>" --apply`
> - *"Here are my hex codes"* — run:
>   `python deep-boards/scripts/brandkit.py colors --accent1 "#XXXXXX" --accent2 "#XXXXXX" --name "<my business>" --apply`
>
> **4. The board.** Ask what I want to show and match it to a type — a big
> number/stat, a checklist, a step-by-step (boxes in a row), or a before/after.
> Ask me for the exact words, and if it's a stat, the exact number. **Use ONLY
> real numbers I give you — never invent, round up, or estimate. No number? Use a
> short phrase.**
>
> **5. Render — ONE command, no editing.** Run the kit's `render.py` with my words
> as arguments and show me the PNG it saves in `deep-boards/examples/output/`. Do
> NOT edit any script, write your own drawing code, or design your own layout —
> `render.py` already makes the on-brand board. Use the matching template:
> - stat: `python deep-boards/render.py stat --number "214" --title "jobs booked last quarter" --label "booked, not chased"`
> - checklist: `python deep-boards/render.py checklist --title "New hire — day one" --item "Laptop ready::set up before they arrive" --item "Meet your buddy::a face on day one"`
> - flow (boxes): `python deep-boards/render.py flow --title "How a missed call becomes a booking" --step "Call comes in::you're on a job" --step "Auto-text fires::in ~30 seconds" --step "They reply::conversation starts" --step "Job booked::saved, not lost"`
> - before/after: `python deep-boards/render.py before-after --title "The intake inbox" --before "Notes everywhere" --before "Leads slip" --after "One place" --after "Every lead replied"`
> (A row/step can be `"phrase::small grey sub-line"` or just `"phrase"`.)
>
> **6. Iterate.** Ask if I want changes (wording, colors, a different board) and repeat.
>
> Rules: the board is drawn by the kit's Python code, never by an image generator —
> so my text and numbers come out exactly as written. If a command errors "file not
> found," it's the folder path — find the real path to `deep-boards` and use it.
> Never write your own drawing code, use an image generator, or design your own
> layout — only `render.py` makes boards (and `brandkit.py` sets colors). If you
> think a board should look different, tell me — don't rebuild it. Keep colors and
> wordmark consistent (they read from `deep-boards/scripts/brand_config.py`). One
> idea per board.

## Use it on any AI

The kit is plain Python + Pillow, so any assistant with a **code tool** can run it
and show you the board:

- **Claude — Cowork (desktop app):** drop the zip into the chat (or add the
  `deep-boards/` folder as a skill), paste the prompt. It unzips, brands, renders,
  shows the PNG.
- **Claude — Claude Code:** put the unzipped kit in your project (or
  `~/.claude/skills/deep-boards/`) and paste the prompt, or just ask for a board.
- **Claude — installed skill:** add `deep-boards` as a skill and it runs the same
  onboarding flow on its own (see `deep-boards/SKILL.md`).
- **ChatGPT — code tool ("code interpreter" / Advanced Data Analysis):** upload the
  zip, paste the prompt. Note: ChatGPT's code sandbox has **no internet**, so the
  "read colors from my website URL" option won't work there — use the **logo** or
  **hex** options instead (the logo → colors reader is offline and works fine).
- **Gemini:** its code tool doesn't support reading or writing files (a Google
  limitation, even in AI Studio), so it can't run this kit in-chat. Use Claude or
  ChatGPT above, or the do-it-yourself path below.
- **Plain claude.ai web chat with no code tool:** it can't run Python, so it can't
  render the image in chat. Use one of the above, or do it yourself below.

Everything the **kit's own code** does is offline — Pillow renders every pixel, and
the logo→colors reader needs no internet. Only the optional "read my website's
colors" step uses your assistant's own web access.

## Why "deep"?

Most auto-generated diagrams are flat: thin boxes and thinner arrows on white.
Deep boards have craft baked in — soft-shadowed cards, real code-drawn icons,
thick hand-drawn arrows, and frame-filling scale — so they read instantly and
look designed, not generated. And because a script draws them (not an image
model), the text is pixel-crisp and you can regenerate a hundred on-brand boards
without a single API call.

## Do it yourself — no AI needed

The scripts run on their own with Python + Pillow. Full walkthrough in
**`QUICKSTART.md`**. Short version (run from inside the unzipped
`deep-boards-starter-kit` folder):

```bash
python3 -m pip install pillow

# brand it in one command (pick one):
python3 deep-boards/scripts/brandkit.py preset "Slate & Blue" --name "My Co" --apply
python3 deep-boards/scripts/brandkit.py logo mylogo.png --name "My Co" --apply
python3 deep-boards/scripts/brandkit.py colors --accent1 "#2F5FE0" --accent2 "#E8590C" --name "My Co" --apply

# render a board:
python3 deep-boards/examples/01_stat_board.py      # → deep-boards/examples/output/
```

Or edit `deep-boards/scripts/brand_config.py` by hand — every board reads from it.

## Install it as a reusable skill (optional)

To keep it around so you can just say *"make me a deep board"* any time, install
`deep-boards` as a skill:

- **Claude Code** — copy the `deep-boards/` folder to `~/.claude/skills/deep-boards/`
  (every project) or `<your-project>/.claude/skills/deep-boards/` (one project).
- **Cowork (Claude desktop app)** — add the `deep-boards/` folder in the app's
  **Skills** settings (or use the separate one-click `.skill` file, if you got it).
- **claude.ai** — add `deep-boards` as a Skill in your workspace's capability settings.

*(Exact menu names move around between app versions — look for "Skills" or
"Capabilities".)* Once installed, it runs the brand-onboarding flow on its own.

## What's inside

```
deep-boards-starter-kit/
├── deep-boards/                ← the installable skill
│   ├── SKILL.md                ← how to design & render boards + brand onboarding
│   ├── scripts/
│   │   ├── make_boards.py      ← the engine: cards, icons, arrows, titles (rarely edited)
│   │   ├── brand_config.py     ← ★ the ONE file that holds your colors + wordmark
│   │   ├── brandkit.py         ← sets colors + wordmark FOR you (logo / preset / hex)
│   │   └── fonts/              ← 3 open-licensed fonts (+ their OFL licenses)
│   └── examples/               ← 4 ready-to-run recipes
├── examples/                   ← the 4 rendered PNGs you see above
├── START-HERE.md               ← ★ upload + paste-the-prompt flow (let your AI brand it)
├── QUICKSTART.md               ← first board in ~10 minutes (do it yourself)
├── README.md                   ← you are here
├── LICENSE                     ← MIT
└── NOTICE.md                   ← lineage + font licenses
```

## Re-brand in one file

Open `deep-boards/scripts/brand_config.py` and change:

- **Colors** — background, ink, card surface, two accents, muted, border.
- **Fonts** — point at any `.ttf`; three open-licensed fonts ship in `fonts/`.
- **Wordmark** — your business name, bottom-left of every board.
- **Canvas** — 16:9 for video/slides, square or portrait for social.

Every board reads from that file. Change it once; everything updates.

## The six patterns

Stat board · Checklist · Process flow · Before/after · Tool map · Callout card.
Four ship as runnable examples; all six are documented in `deep-boards/SKILL.md`.

## License

MIT — see `LICENSE`. Use it, change it, ship boards with it, commercial or not.
Lineage and the bundled font licenses (SIL Open Font License) are in `NOTICE.md`.

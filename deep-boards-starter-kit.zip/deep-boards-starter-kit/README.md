# Deep Boards — Starter Kit

Make clean, on-brand whiteboard-style graphics — **deep boards** — as code-drawn
PNGs. A stat card, a process flow, a before/after, a checklist: the visuals that
make one idea land in seconds.

**Zero keys. Zero image models. Zero hallucinated numbers.** Every board is drawn
by [Pillow](https://python-pillow.org/) from the text you give it, so your words
and figures are always exact and always on-brand. Re-brand the whole system to
any business by editing **one file**.

<p align="center">
  <img src="examples/01_stat_board.png" width="48%" alt="Stat board example">
  <img src="examples/03_process_flow.png" width="48%" alt="Process flow example"><br>
  <img src="examples/04_before_after.png" width="48%" alt="Before / after example">
  <img src="examples/02_checklist_board.png" width="48%" alt="Checklist example">
</p>

*(The demo brand — "Northwind" — is made up. The colors are the kit's own neutral
demo palette. Swap in yours in one file.)*

---

## Why "deep"?

Most auto-generated diagrams are flat: thin boxes and thinner arrows on white.
Deep boards have craft baked in — soft-shadowed cards, real code-drawn icons,
thick hand-drawn arrows, and frame-filling scale — so they read instantly and
look designed, not generated. And because a script draws them (not an image
model), the text is pixel-crisp and you can regenerate a hundred on-brand boards
without a single API call.

## Get your first board in 10 minutes

See **`QUICKSTART.md`**. Short version:

```bash
python3 -m pip install pillow
cd deep-boards/examples
python3 01_stat_board.py      # saves to ./output/01_stat_board.png
```

Then edit `deep-boards/scripts/brand_config.py` to make it yours.

## Install it as a skill (optional)

You do **not** need Claude to use this kit — the scripts run on their own with
Python + Pillow. But if you use Claude, install `deep-boards` as a skill and just
ask for a board in plain language.

- **Claude Code** — copy the `deep-boards/` folder into `~/.claude/skills/deep-boards/`
  (available in every project) or `<your-project>/.claude/skills/deep-boards/`
  (one project). Then ask: *"make me a deep board that says…"*
- **Cowork (Claude desktop app)** — install the included `.skill` file for
  one-click setup, or add the `deep-boards/` folder in the app's **Skills**
  settings. Then ask Cowork for a board.
- **claude.ai** — add `deep-boards` as a Skill in your workspace's capability
  settings, then ask for a board in any chat or Project.
- **No Claude at all** — run the example scripts directly (see Quickstart).

*(Exact menu names move around between app versions — look for "Skills" or
"Capabilities" in settings.)*

## What's inside

```
deep-boards-starter-kit/
├── deep-boards/                ← the installable skill
│   ├── SKILL.md                ← how to design & render boards (start here after quickstart)
│   ├── scripts/
│   │   ├── make_boards.py      ← the engine: cards, icons, arrows, titles (rarely edited)
│   │   ├── brand_config.py     ← ★ the ONE file you edit to re-brand everything
│   │   └── fonts/              ← 3 open-licensed fonts (+ their OFL licenses)
│   └── examples/               ← 4 ready-to-run recipes
├── examples/                   ← the 4 rendered PNGs you see above
├── QUICKSTART.md               ← first board in ~10 minutes
├── README.md                   ← you are here
├── LICENSE                     ← MIT
└── NOTICE.md                   ← lineage + font licenses
```

## Re-brand in one file

Open `deep-boards/scripts/brand_config.py` and change:

- **Colors** — background, ink, card surface, two accents, muted, border.
- **Fonts** — point at any `.ttf`; three open-licensed fonts ship in `fonts/`.
- **Wordmark** — your business name, bottom-left of every board.
- **Canvas** — 16:9 for video/slides, square or portrait for social.

Every board reads from that file. Change it once; everything updates.

## The six patterns

Stat board · Checklist · Process flow · Before/after · Tool map · Callout card.
Four ship as runnable examples; all six are documented in `deep-boards/SKILL.md`.

## License

MIT — see `LICENSE`. Use it, change it, ship boards with it, commercial or not.
Lineage and the bundled font licenses (SIL Open Font License) are in `NOTICE.md`.
